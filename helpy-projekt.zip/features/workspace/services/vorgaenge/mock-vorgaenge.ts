import { getBrainV2Items } from "@/features/brain/services/brain-v2";
import { mapPreparedWorkItemsToVorgaenge } from "@/features/workspace/services/vorgaenge/brain-v2-mapper";
import {
  getEffectiveVorgangStatus,
  isVorgangActiveOpen,
  isVorgangAwaitingCustomerReply,
} from "@/features/workspace/services/vorgaenge/vorgang-effective-status";
import type { Vorgang, VorgangFilter } from "@/features/workspace/services/vorgaenge/types";

export function getBrainV2Vorgaenge(): Vorgang[] {
  return mapPreparedWorkItemsToVorgaenge(getBrainV2Items());
}

export { getEffectiveVorgangStatus };

export function filterVorgaenge(
  vorgaenge: Vorgang[],
  filter: VorgangFilter
): Vorgang[] {
  if (filter === "alle") {
    return vorgaenge.filter((v) => isVorgangActiveOpen(v));
  }
  if (filter === "wartend") {
    return vorgaenge.filter((v) => isVorgangAwaitingCustomerReply(v));
  }
  return vorgaenge.filter((v) => getEffectiveVorgangStatus(v) === filter);
}

export function getVorgangFilterCounts(
  vorgaenge: Vorgang[]
): Record<VorgangFilter, number> {
  const activeOpen = vorgaenge.filter((v) => isVorgangActiveOpen(v));
  return {
    alle: activeOpen.length,
    neu: vorgaenge.filter((v) => getEffectiveVorgangStatus(v) === "neu").length,
    in_bearbeitung: vorgaenge.filter(
      (v) => getEffectiveVorgangStatus(v) === "in_bearbeitung"
    ).length,
    erledigt: vorgaenge.filter((v) => getEffectiveVorgangStatus(v) === "erledigt")
      .length,
    wartend: vorgaenge.filter((v) => isVorgangAwaitingCustomerReply(v)).length,
  };
}

const PRIORITY_ORDER = {
  kritisch: 0,
  hoch: 1,
  mittel: 2,
  niedrig: 3,
} as const;

export function sortVorgaengeByPriority(vorgaenge: Vorgang[]): Vorgang[] {
  return [...vorgaenge].sort(
    (a, b) => PRIORITY_ORDER[a.prioritaet] - PRIORITY_ORDER[b.prioritaet]
  );
}

/** @deprecated Legacy mock — Brain v2 ist die Quelle */
export const mockVorgaenge: Vorgang[] = getBrainV2Vorgaenge();
