"use client";

import { useMemo } from "react";
import { Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Panel, PanelBody, PanelHeader } from "@/components/ui/Panel";
import { HelpyAvatar } from "@/components/helpy/helpy-avatar";
import type { BrainV2Summary } from "@/features/brain/services/brain-v2";
import { getEffectiveVorgangStatus, isVorgangActiveOpen } from "@/features/workspace/services/vorgaenge/vorgang-effective-status";
import {
  getGmailAutoSyncServerSnapshot,
  getGmailAutoSyncState,
  subscribeGmailAutoSyncPanel,
} from "@/features/gmail/services/gmail-auto-sync";
import { STATUS_PANEL_MESSAGE } from "@/features/workspace/services/status";
import {
  buildVorgaengeCentralSummary,
  subscribeVorgaengeCounts,
} from "@/features/workspace/services/vorgaenge/vorgaenge-summary";
import type { Vorgang } from "@/features/workspace/services/vorgaenge/types";
import { useTerminology } from "@/features/workspace/services/terminology";
import { useExternalStore } from "@/lib/hooks/use-external-store";
import { useStoreRevision } from "@/lib/hooks/use-store-revision";

type HelpyVorgaengePanelProps = {
  vorgaenge: Vorgang[];
  allVorgaenge: Vorgang[];
  summary: BrainV2Summary;
  useMailSource?: boolean;
  panelMessage?: string | null;
};

const MAIL_INTRO_MESSAGE =
  "Ich habe deine E-Mails geprüft und daraus vorbereitete Vorgänge erstellt.";

export function HelpyVorgaengePanel({
  vorgaenge,
  allVorgaenge,
  summary,
  useMailSource = false,
  panelMessage = null,
}: HelpyVorgaengePanelProps) {
  const { t } = useTerminology();
  const countsRevision = useStoreRevision(subscribeVorgaengeCounts);
  const autoSyncState = useExternalStore(
    subscribeGmailAutoSyncPanel,
    getGmailAutoSyncState,
    getGmailAutoSyncServerSnapshot
  );

  const centralSummary = useMemo(
    () => buildVorgaengeCentralSummary(allVorgaenge),
    [allVorgaenge, countsRevision]
  );
  const statusSummary = centralSummary.dailyStatus;
  const topVorgang = vorgaenge[0];

  const mailOverview = useMailSource
    ? {
        kritisch: allVorgaenge.filter(
          (item) =>
            isVorgangActiveOpen(item) &&
            item.prioritaet === "kritisch"
        ).length,
        hoch: allVorgaenge.filter(
          (item) =>
            isVorgangActiveOpen(item) &&
            item.prioritaet === "hoch"
        ).length,
        neueKunden: allVorgaenge.filter(
          (item) =>
            isVorgangActiveOpen(item) &&
            (item.typ === "neuer_kunde" || item.typ === "anfrage")
        ).length,
        vorbereiteteAngebote: allVorgaenge.filter(
          (item) =>
            isVorgangActiveOpen(item) &&
            item.typ === "angebotsanfrage"
        ).length,
      }
    : null;

  const overview = mailOverview ?? {
    kritisch: summary.kritisch,
    hoch: summary.hoch,
    neueKunden: summary.neueKunden,
    vorbereiteteAngebote: summary.vorbereiteteAngebote,
  };
  const introMessage =
    panelMessage ??
    (useMailSource && autoSyncState.panelMessage
      ? autoSyncState.panelMessage
      : useMailSource
        ? MAIL_INTRO_MESSAGE
        : summary.introMessage);

  return (
    <Panel variant="helpy">
      <PanelHeader className="h-auto items-start py-5">
        <div className="flex items-center gap-3">
          <HelpyAvatar />
          <div>
            <h2 className="text-sm font-semibold tracking-[-0.01em] text-[#0F172A]">
              HELPY
            </h2>
            <p className="text-[11px] font-medium text-[#64748B]">
              Dein KI-Bürokollege
            </p>
          </div>
        </div>
      </PanelHeader>

      <PanelBody>
        <div className="space-y-5">
          <div className="helpy-fade-in">
            <p className="text-[13px] leading-relaxed text-[#334155]">
              {introMessage}
            </p>
            {!useMailSource && (
              <p className="mt-2 text-[12px] leading-relaxed text-[#64748B]">
                {summary.priorityHint}
              </p>
            )}
          </div>

          <Card className="helpy-fade-in rounded-[20px] border-[#CBD5E1]/40 bg-white/90 py-0 shadow-sm backdrop-blur-sm">
            <CardContent className="p-5">
              <p className="text-[12px] font-semibold text-[#0F172A]">Heute</p>
              <ul className="mt-3 space-y-2.5">
                <li className="flex items-center justify-between text-[12px] text-[#334155]">
                  <span>Vorgänge vorbereitet</span>
                  <span className="font-semibold text-[#2563EB]">
                    {statusSummary.vorbereitet}
                  </span>
                </li>
                <li className="flex items-center justify-between text-[12px] text-[#334155]">
                  <span>Warten auf Prüfung</span>
                  <span className="font-semibold text-[#B45309]">
                    {statusSummary.wartenAufPruefung}
                  </span>
                </li>
                <li className="flex items-center justify-between text-[12px] text-[#334155]">
                  <span>Bestätigt</span>
                  <span className="font-semibold text-[#047857]">
                    {statusSummary.bestaetigt}
                  </span>
                </li>
                <li className="flex items-center justify-between text-[12px] text-[#334155]">
                  <span>Erledigt</span>
                  <span className="font-semibold text-[#64748B]">
                    {statusSummary.erledigt}
                  </span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="helpy-fade-in rounded-[20px] border-[#BFDBFE]/40 bg-gradient-to-br from-[#EFF6FF]/60 to-white/90 py-0 shadow-sm backdrop-blur-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-2">
                <Sparkles className="size-4 text-[#2563EB]" strokeWidth={2} />
                <p className="text-[12px] font-semibold text-[#0F172A]">
                  HELPY sagt
                </p>
              </div>
              <p className="mt-3 text-[12px] leading-[1.65] text-[#334155]">
                {STATUS_PANEL_MESSAGE}
              </p>
            </CardContent>
          </Card>

          <Card className="helpy-fade-in rounded-[20px] border-[#CBD5E1]/40 bg-white/90 py-0 shadow-sm backdrop-blur-sm">
            <CardContent className="p-5">
              <p className="text-[12px] font-semibold text-[#0F172A]">
                Übersicht
              </p>
              <ul className="mt-3 space-y-2.5">
                <li className="flex items-center justify-between text-[12px] text-[#334155]">
                  <span>Kritisch</span>
                  <span className="font-semibold text-[#DC2626]">
                    {overview.kritisch}
                  </span>
                </li>
                <li className="flex items-center justify-between text-[12px] text-[#334155]">
                  <span>Hoch</span>
                  <span className="font-semibold text-[#B45309]">
                    {overview.hoch}
                  </span>
                </li>
                <li className="flex items-center justify-between text-[12px] text-[#334155]">
                  <span>{t("customerNew", { form: "plural" })}</span>
                  <span className="font-semibold text-[#2563EB]">
                    {overview.neueKunden}
                  </span>
                </li>
                <li className="flex items-center justify-between text-[12px] text-[#334155]">
                  <span>
                    Vorbereitete {t("offer", { form: "plural" })}
                  </span>
                  <span className="font-semibold text-[#2563EB]">
                    {overview.vorbereiteteAngebote}
                  </span>
                </li>
              </ul>
            </CardContent>
          </Card>

          {topVorgang && (
            <Card className="helpy-fade-in rounded-[20px] border-[#CBD5E1]/40 bg-white/90 py-0 shadow-sm backdrop-blur-sm">
              <CardContent className="p-5">
                <div className="flex items-center gap-2">
                  <Sparkles className="size-4 text-[#2563EB]" strokeWidth={2} />
                  <p className="text-[12px] font-semibold text-[#0F172A]">
                    Meine Empfehlung
                  </p>
                </div>
                <p className="mt-3 text-[12px] leading-[1.65] text-[#334155]">
                  {topVorgang.helpyEmpfehlung}
                </p>
              </CardContent>
            </Card>
          )}

          <Card className="helpy-fade-in rounded-[20px] border-[#CBD5E1]/40 bg-white/90 py-0 shadow-sm backdrop-blur-sm">
            <CardContent className="p-5">
              <p className="text-[12px] font-semibold text-[#0F172A]">
                Vorbereitete Vorgänge
              </p>
              <ul className="mt-3 space-y-2">
                {vorgaenge.slice(0, 5).map((v) => (
                  <li
                    key={v.id}
                    className="flex items-center gap-2.5 text-[12px] text-[#334155]"
                  >
                    <span className="text-[14px] leading-none">{v.emoji}</span>
                    <span className="min-w-0 truncate">
                      {v.intentLabel ?? v.titel}
                    </span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </PanelBody>
    </Panel>
  );
}
