"use client";

import { useMemo, useState } from "react";
import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { CustomerProfile } from "@/features/customers/components/customer-profile";
import { HelpyKundenPanel } from "@/features/customers/components/helpy-kunden-panel";
import { KundenPicker } from "@/features/customers/components/kunden-picker";
import { KundenToolbar } from "@/features/customers/components/kunden-toolbar";
import {
  filterCustomers,
  getFilterCounts,
  mockCustomers,
  searchCustomers,
  type CustomerFilter,
} from "@/features/customers/mock/mock-customers";
import { useConfirmedKundenakten } from "@/features/kundenakte/hooks/use-kundenakte";
import { mergeCustomersWithConfirmedKundenakten } from "@/features/kundenakte/services/kundenakte-mapper";

export function KundenPage() {
  const confirmedKundenakten = useConfirmedKundenakten();
  const customers = useMemo(
    () => mergeCustomersWithConfirmedKundenakten(mockCustomers, confirmedKundenakten),
    [confirmedKundenakten]
  );

  const [activeFilter, setActiveFilter] = useState<CustomerFilter>("alle");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedId, setSelectedId] = useState(customers[0]?.id ?? "");

  const filterCounts = useMemo(() => getFilterCounts(customers), [customers]);

  const filteredCustomers = useMemo(() => {
    const byFilter = filterCustomers(customers, activeFilter);
    return searchCustomers(byFilter, searchQuery);
  }, [activeFilter, customers, searchQuery]);

  const selectedCustomer =
    customers.find((c) => c.id === selectedId) ??
    filteredCustomers[0] ??
    null;

  const handleFilterChange = (filter: CustomerFilter) => {
    setActiveFilter(filter);
    const next = searchCustomers(filterCustomers(customers, filter), searchQuery);
    if (next.length > 0 && !next.some((c) => c.id === selectedId)) {
      setSelectedId(next[0].id);
    }
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
    const next = searchCustomers(
      filterCustomers(customers, activeFilter),
      query
    );
    if (next.length > 0 && !next.some((c) => c.id === selectedId)) {
      setSelectedId(next[0].id);
    }
  };

  return (
    <DashboardShell
      activeHref="/kunden"
      rightPanel={<HelpyKundenPanel customer={selectedCustomer} />}
    >
      <div className="flex h-full min-h-0 flex-col overflow-hidden">
        <KundenToolbar
          activeFilter={activeFilter}
          onFilterChange={handleFilterChange}
          filterCounts={filterCounts}
          searchQuery={searchQuery}
          onSearchChange={handleSearchChange}
        />
        <KundenPicker
          customers={filteredCustomers}
          selectedId={selectedCustomer?.id ?? ""}
          onSelect={setSelectedId}
        />
        <div className="min-h-0 flex-1 overflow-hidden">
          <CustomerProfile customer={selectedCustomer} />
        </div>
      </div>
    </DashboardShell>
  );
}
